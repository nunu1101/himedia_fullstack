package com.ohgiraffers.section01.user_type;

public class Member {

    // 이것을 전역 변수라고 하고, (필드 == 인스턴스변수 == 속성) 라고 부른다.
    String id;
    String pw;
    String name;
    int age;
    char gender;
    String[] hobby;

}
