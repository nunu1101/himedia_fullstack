package com.ohgiraffers.section02.encapsulation.problem2;

public class Monster {

    String name;
    int hp;
}
