package com.ohgiraffers.section01.test;

public class Female extends Human{
    public void info(){
        System.out.println("나는 여자입니다.");
    }
}
