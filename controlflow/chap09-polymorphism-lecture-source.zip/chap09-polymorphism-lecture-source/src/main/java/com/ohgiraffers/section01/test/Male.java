package com.ohgiraffers.section01.test;

public class Male extends Human{
    public void info(){
        System.out.println("나는 남자입니다.");
    }
}
