package com.ohgiraffers.section01.test;

public class Human {
    public void info(){
        System.out.println("나는 사람입니다.");
    }
}
