package com.ohgiraffers.section01.generic.practice;

public class Dog extends LandAnimal{
    @Override
    public void crying() {
        System.out.println("멍멍");
    }
}
