package com.ohgiraffers.section02.extend;

public interface Animal {
}
