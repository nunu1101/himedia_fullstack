package com.ohgiraffers.section01.generic.practice;

public class LandAnimal {
    public void crying(){
        System.out.println("육지동물");
    }
}
