package com.ohgiraffers.section02.extend;

public class Reptile implements Animal {
}
