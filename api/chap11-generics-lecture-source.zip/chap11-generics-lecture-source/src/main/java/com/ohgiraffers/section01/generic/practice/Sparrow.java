package com.ohgiraffers.section01.generic.practice;

public class Sparrow {
    public void crying() {
        System.out.println("짹짹");
    }
}
