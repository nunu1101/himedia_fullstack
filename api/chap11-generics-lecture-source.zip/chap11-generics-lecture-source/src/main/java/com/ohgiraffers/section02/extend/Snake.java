package com.ohgiraffers.section02.extend;

public class Snake extends Reptile {

}
