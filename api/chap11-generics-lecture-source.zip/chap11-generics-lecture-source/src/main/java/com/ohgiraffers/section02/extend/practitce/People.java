package com.ohgiraffers.section02.extend.practitce;

public class People {
    //필드(Feild)
    String name;
    int age;

    //메소드
    public void printMyself(){
        System.out.println("이름 : " + name);
        System.out.println("나이 : " + age);
    }
}
