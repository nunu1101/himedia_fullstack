package com.ohgiraffers;

public class KaKaoBlue {
}
