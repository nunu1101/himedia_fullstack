package com.ohgiraffers;

import java.util.Scanner;

public class Customer {
        private int checkSchedule;
        private boolean getIn;

    public Customer(){
            this.checkSchedule = 0;
            this.getIn = false;
        }

        // 약속시간 확인


        public void setCheckSchedule(int checkSchedule) {
            this.checkSchedule = checkSchedule;
            System.out.println("약속 시간에 " +checkSchedule+ " 분 늦었습니다.");
        }


}
