package com.ohgiraffers;

public class KakaoGeneral {
}
