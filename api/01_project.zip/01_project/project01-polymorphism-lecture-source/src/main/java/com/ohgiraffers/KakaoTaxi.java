package com.ohgiraffers;

public class KakaoTaxi {

    private int checkSchedule;
    private boolean getIn;

    public void customerIn() {
        System.out.println("승객이 택시에 탑승합니다.");
    }

    public void checkDestination(){
        System.out.println("승객의 목적지를 확인합니다.");
    }

    public void run(){
        System.out.println("목적지 확인 후 출발합니다.");
    }

    public void arriveDestination(){
        System.out.println("목적지에 도착하였습니다.");
    }

}
