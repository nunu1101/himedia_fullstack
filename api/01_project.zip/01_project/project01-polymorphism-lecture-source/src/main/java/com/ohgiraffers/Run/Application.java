package com.ohgiraffers.Run;

import com.ohgiraffers.Customer;
import com.ohgiraffers.KakaoTaxi;

import java.util.Scanner;

public class Application {
    public static void main(String[] args) {

        /* Read Me */

        /* 승객과 택시의 상호작용 */

        /* 택시가 동작하는 것 */
        /*  1. 승객을 태운다.
         *  2. 목적지를 확인한다. ( 목적지 확인 후 1000m가 넘으면 200원씩 추가 (택시마다 기본금액 / 추가 금액 다름) )
         *  3. 목적지로 출발한다.
         *  4. 목적지에 도착한다. (멈춘다)
         *  5. 결제를 한다. ( cash or credit )
         */

        /* 승객의 행위 */
        /*  1. 약속에 늦었다면 택시를 잡음
         *  2. 택시의 종류 선택 ( 약속에 늦은만큼 택시의 종류가 달라짐 )
         *  2. 택시를 잡은 후 거리를 미터 단위로 설정
         *  3. 결제를 한다. ( cash or credit )
         *  4. 내린다.
         */

        /* 카O오 택시의 다형성 */
        /* 1. 일반호출
         * 2. 블루호출
         * 3. 블랙호출
         */


        // 택시 객체 생성
        KakaoTaxi kakaoTaxi = new KakaoTaxi();
        // 승객 객체 생성
        Customer customer = new Customer();
        Scanner sc = new Scanner(System.in);

        // 약속시간 확인
        System.out.print("약속시간에 늦었습니다. 시계를 확인하니(10/20/30 중 입력하세요) : ");
        int no = sc.nextInt();

        if(no == 10) {
            customer.setCheckSchedule(10);
        } else if (no == 20) {
            customer.setCheckSchedule(20);
        } else {
            customer.setCheckSchedule(30);
        }
    }
}
