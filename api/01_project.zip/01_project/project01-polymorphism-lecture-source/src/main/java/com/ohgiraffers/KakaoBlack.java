package com.ohgiraffers;

public class KakaoBlack {
}
